--
-- PostgreSQL database dump
--

\restrict 4FcOf9HmPeVTAXp2aGXlYyiWmAJUab7Qoax6d7eoc9Bk6AqKpm6Z6Tod6rbHbfR

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: guests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.guests (
    id integer NOT NULL,
    guest_code character varying(20),
    full_name character varying(100) NOT NULL,
    email character varying(100),
    phone character varying(20),
    address text,
    id_number character varying(50),
    nationality character varying(50),
    preferences jsonb DEFAULT '{}'::jsonb,
    total_stays integer DEFAULT 0,
    total_spent numeric(10,2) DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.guests OWNER TO postgres;

--
-- Name: guests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.guests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.guests_id_seq OWNER TO postgres;

--
-- Name: guests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.guests_id_seq OWNED BY public.guests.id;


--
-- Name: housekeeping_tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.housekeeping_tasks (
    id integer NOT NULL,
    room_id integer,
    task_type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    assigned_to character varying(100),
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.housekeeping_tasks OWNER TO postgres;

--
-- Name: housekeeping_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.housekeeping_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.housekeeping_tasks_id_seq OWNER TO postgres;

--
-- Name: housekeeping_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.housekeeping_tasks_id_seq OWNED BY public.housekeeping_tasks.id;


--
-- Name: pos_transaction_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_transaction_lines (
    id integer NOT NULL,
    transaction_id integer,
    product_id integer,
    product_name character varying(100) NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    line_total numeric(10,2) NOT NULL,
    modifiers jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pos_transaction_lines OWNER TO postgres;

--
-- Name: pos_transaction_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pos_transaction_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pos_transaction_lines_id_seq OWNER TO postgres;

--
-- Name: pos_transaction_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pos_transaction_lines_id_seq OWNED BY public.pos_transaction_lines.id;


--
-- Name: pos_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pos_transactions (
    id integer NOT NULL,
    transaction_number character varying(20) NOT NULL,
    guest_id integer,
    reservation_id integer,
    room_number character varying(10),
    server_name character varying(100),
    outlet character varying(50),
    subtotal numeric(10,2) NOT NULL,
    tax_amount numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) NOT NULL,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    posted_to_folio boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pos_transactions OWNER TO postgres;

--
-- Name: pos_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pos_transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pos_transactions_id_seq OWNER TO postgres;

--
-- Name: pos_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pos_transactions_id_seq OWNED BY public.pos_transactions.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    sku character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50),
    unit character varying(20) DEFAULT 'piece'::character varying,
    unit_cost numeric(10,2) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    tax_rate numeric(5,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    current_stock integer DEFAULT 0,
    reorder_level integer DEFAULT 0,
    location character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservations (
    id integer NOT NULL,
    reservation_number character varying(20) NOT NULL,
    guest_id integer,
    room_id integer,
    check_in date NOT NULL,
    check_out date NOT NULL,
    adults integer DEFAULT 1,
    children integer DEFAULT 0,
    total_amount numeric(10,2),
    paid_amount numeric(10,2) DEFAULT 0,
    status character varying(20) DEFAULT 'confirmed'::character varying,
    source character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.reservations OWNER TO postgres;

--
-- Name: reservations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reservations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reservations_id_seq OWNER TO postgres;

--
-- Name: reservations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reservations_id_seq OWNED BY public.reservations.id;


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    room_number character varying(10) NOT NULL,
    room_type character varying(50) NOT NULL,
    floor_number integer,
    bed_count integer DEFAULT 1,
    max_occupancy integer DEFAULT 2,
    base_price numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'ready'::character varying,
    is_available boolean DEFAULT true,
    last_maintenance date,
    notes text
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rooms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rooms_id_seq OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rooms_id_seq OWNED BY public.rooms.id;


--
-- Name: staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.staff (
    id integer NOT NULL,
    staff_code character varying(20) NOT NULL,
    full_name character varying(100) NOT NULL,
    email character varying(100),
    role character varying(50) NOT NULL,
    department character varying(50),
    is_active boolean DEFAULT true,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.staff OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_id_seq OWNER TO postgres;

--
-- Name: staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.staff_id_seq OWNED BY public.staff.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    product_id integer,
    quantity_change integer NOT NULL,
    reason character varying(50) NOT NULL,
    reference_id integer,
    notes text,
    created_by character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO postgres;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.test OWNER TO postgres;

--
-- Name: test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_id_seq OWNER TO postgres;

--
-- Name: test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_id_seq OWNED BY public.test.id;


--
-- Name: guests id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests ALTER COLUMN id SET DEFAULT nextval('public.guests_id_seq'::regclass);


--
-- Name: housekeeping_tasks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.housekeeping_tasks ALTER COLUMN id SET DEFAULT nextval('public.housekeeping_tasks_id_seq'::regclass);


--
-- Name: pos_transaction_lines id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transaction_lines ALTER COLUMN id SET DEFAULT nextval('public.pos_transaction_lines_id_seq'::regclass);


--
-- Name: pos_transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transactions ALTER COLUMN id SET DEFAULT nextval('public.pos_transactions_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: reservations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations ALTER COLUMN id SET DEFAULT nextval('public.reservations_id_seq'::regclass);


--
-- Name: rooms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms ALTER COLUMN id SET DEFAULT nextval('public.rooms_id_seq'::regclass);


--
-- Name: staff id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff ALTER COLUMN id SET DEFAULT nextval('public.staff_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test ALTER COLUMN id SET DEFAULT nextval('public.test_id_seq'::regclass);


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.guests (id, guest_code, full_name, email, phone, address, id_number, nationality, preferences, total_stays, total_spent, created_at) FROM stdin;
1	GUEST-001	John Smith	john.smith@example.com	+1234567890	\N	\N	\N	{"coffee": "decaf", "pillow": "firm"}	0	0.00	2026-04-08 19:22:04.360656
\.


--
-- Data for Name: housekeeping_tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.housekeeping_tasks (id, room_id, task_type, status, assigned_to, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: pos_transaction_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_transaction_lines (id, transaction_id, product_id, product_name, quantity, unit_price, line_total, modifiers, created_at) FROM stdin;
4	1	1	Local Beer	3	4.00	12.00	[]	2026-04-08 22:09:40.057492
5	1	3	Fresh Coffee	2	3.00	6.00	[]	2026-04-08 22:09:40.057492
\.


--
-- Data for Name: pos_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pos_transactions (id, transaction_number, guest_id, reservation_id, room_number, server_name, outlet, subtotal, tax_amount, total_amount, payment_status, posted_to_folio, created_at) FROM stdin;
1	TRX-001	1	\N	\N	\N	\N	50.00	5.00	55.00	paid	f	2026-04-08 00:00:00
2	TRX-002	1	\N	\N	\N	\N	35.00	3.50	38.50	paid	f	2026-04-07 00:00:00
3	TRX-003	1	\N	\N	\N	\N	75.00	7.50	82.50	pending	f	2026-04-06 00:00:00
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, sku, name, category, unit, unit_cost, unit_price, tax_rate, is_active, current_stock, reorder_level, location, created_at) FROM stdin;
1	BEER-001	Local Beer	beverage	bottle	1.50	4.00	0.00	t	200	50	Bar Cooler	2026-04-08 19:21:42.794752
3	COFFEE-001	Fresh Coffee	beverage	cup	0.50	3.00	0.00	t	150	40	Kitchen	2026-04-08 19:21:42.794752
4	STEAK-001	Grilled Steak	food	piece	8.00	25.00	0.00	t	30	10	Kitchen Freezer	2026-04-08 19:21:42.794752
6	SODA-001	Soft Drink	beverage	can	0.80	2.50	0.00	t	100	30	Bar Cooler	2026-04-08 19:21:42.794752
2	WINE-001	House Wine	beverage	glass	2.00	6.00	0.00	t	1	30	Bar Cooler	2026-04-08 19:21:42.794752
5	BURGER-001	Beef Burger	food	piece	3.50	12.00	0.00	t	0	8	Kitchen Freezer	2026-04-08 19:21:42.794752
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservations (id, reservation_number, guest_id, room_id, check_in, check_out, adults, children, total_amount, paid_amount, status, source, notes, created_at) FROM stdin;
8	RES-2024-001	1	1	2026-04-08	2026-04-11	2	0	320.00	0.00	confirmed	\N	\N	2026-04-08 19:31:12.172318
\.


--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, room_number, room_type, floor_number, bed_count, max_occupancy, base_price, status, is_available, last_maintenance, notes) FROM stdin;
1	101	Standard	1	1	2	80.00	ready	t	\N	\N
2	102	Standard	1	1	2	80.00	ready	t	\N	\N
4	201	Deluxe	2	1	2	120.00	ready	t	\N	\N
6	301	Suite	3	1	2	200.00	ready	t	\N	\N
3	103	Standard	1	2	3	90.00	dirty	f	\N	\N
5	202	Deluxe	2	1	2	120.00	dirty	f	\N	\N
\.


--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.staff (id, staff_code, full_name, email, role, department, is_active, password_hash, created_at) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (id, product_id, quantity_change, reason, reference_id, notes, created_by, created_at) FROM stdin;
1	5	-2	stocktake	\N	Adjusted from 25 to 23	manager	2026-04-08 21:13:34.180071
2	2	5	stocktake	\N	Adjusted from 100 to 105	manager	2026-04-08 21:13:47.114465
3	2	-104	stocktake	\N	Adjusted from 105 to 1	manager	2026-04-08 21:14:47.426336
4	5	-23	stocktake	\N	Adjusted from 23 to 0	manager	2026-04-08 21:15:47.688943
\.


--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test (id, name) FROM stdin;
\.


--
-- Name: guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.guests_id_seq', 5, true);


--
-- Name: housekeeping_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.housekeeping_tasks_id_seq', 1, false);


--
-- Name: pos_transaction_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pos_transaction_lines_id_seq', 5, true);


--
-- Name: pos_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pos_transactions_id_seq', 3, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 8, true);


--
-- Name: reservations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reservations_id_seq', 8, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 8, true);


--
-- Name: staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.staff_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 4, true);


--
-- Name: test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_id_seq', 1, false);


--
-- Name: guests guests_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_email_key UNIQUE (email);


--
-- Name: guests guests_guest_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_guest_code_key UNIQUE (guest_code);


--
-- Name: guests guests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.guests
    ADD CONSTRAINT guests_pkey PRIMARY KEY (id);


--
-- Name: housekeeping_tasks housekeeping_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.housekeeping_tasks
    ADD CONSTRAINT housekeeping_tasks_pkey PRIMARY KEY (id);


--
-- Name: pos_transaction_lines pos_transaction_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transaction_lines
    ADD CONSTRAINT pos_transaction_lines_pkey PRIMARY KEY (id);


--
-- Name: pos_transactions pos_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_pkey PRIMARY KEY (id);


--
-- Name: pos_transactions pos_transactions_transaction_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_transaction_number_key UNIQUE (transaction_number);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_key UNIQUE (sku);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_reservation_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_reservation_number_key UNIQUE (reservation_number);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_room_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_room_number_key UNIQUE (room_number);


--
-- Name: staff staff_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_email_key UNIQUE (email);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_staff_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_staff_code_key UNIQUE (staff_code);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: idx_pos_transaction_lines_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pos_transaction_lines_product ON public.pos_transaction_lines USING btree (product_id);


--
-- Name: idx_pos_transaction_lines_transaction; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pos_transaction_lines_transaction ON public.pos_transaction_lines USING btree (transaction_id);


--
-- Name: pos_transaction_lines fk_pos_transaction_lines_transaction; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transaction_lines
    ADD CONSTRAINT fk_pos_transaction_lines_transaction FOREIGN KEY (transaction_id) REFERENCES public.pos_transactions(id) ON DELETE CASCADE;


--
-- Name: housekeeping_tasks housekeeping_tasks_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.housekeeping_tasks
    ADD CONSTRAINT housekeeping_tasks_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: pos_transactions pos_transactions_guest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_guest_id_fkey FOREIGN KEY (guest_id) REFERENCES public.guests(id);


--
-- Name: pos_transactions pos_transactions_reservation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pos_transactions
    ADD CONSTRAINT pos_transactions_reservation_id_fkey FOREIGN KEY (reservation_id) REFERENCES public.reservations(id);


--
-- Name: reservations reservations_guest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_guest_id_fkey FOREIGN KEY (guest_id) REFERENCES public.guests(id);


--
-- Name: reservations reservations_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 4FcOf9HmPeVTAXp2aGXlYyiWmAJUab7Qoax6d7eoc9Bk6AqKpm6Z6Tod6rbHbfR

